const data = {
  "timers": [
    { "name": "Timer 1", "duration": 300, "color": "red", "soundType": "beep" },
    { "name": "Andrea", "duration": 60, "color": "red", "soundType": "bell" },
    { "name": "Timer 3", "duration": 300, "color": "yellow", "soundType": "beep" }
  ]
};

const timersDiv = document.getElementById('timers');

data.timers.forEach((timer, index) => {
  const card = document.createElement('div');
  card.className = 'timer-card';
  card.style.borderTop = `8px solid ${timer.color}`;

  const name = document.createElement('div');
  name.className = 'timer-name';
  name.textContent = timer.name;

  const timeDisplay = document.createElement('div');
  timeDisplay.className = 'timer-time';
  timeDisplay.textContent = formatTime(timer.duration);

  const button = document.createElement('button');
  button.className = 'timer-button';
  button.textContent = 'Start';

  let countdown;
  button.addEventListener('click', () => {
    clearInterval(countdown);
    let remaining = timer.duration;

    countdown = setInterval(() => {
      remaining--;
      timeDisplay.textContent = formatTime(remaining);
      if (remaining <= 0) {
        clearInterval(countdown);
        playSound(timer.soundType);
        alert(`${timer.name} finito!`);
      }
    }, 1000);
  });

  card.appendChild(name);
  card.appendChild(timeDisplay);
  card.appendChild(button);
  timersDiv.appendChild(card);
});

function formatTime(seconds) {
  const min = String(Math.floor(seconds / 60)).padStart(2, '0');
  const sec = String(seconds % 60).padStart(2, '0');
  return `${min}:${sec}`;
}

function playSound(type) {
  const sound = document.getElementById(type);
  if (sound) sound.play();
}
